const { Router } = require('express'); 
// const authUtils=require("../auth/authUtils")
const TimesheetControllers=require("../controller/timesheetController")
const router = Router();

router.post('/getTimesheetData',TimesheetControllers.RertreiveTimesheetPerWeek)
router.get('/getUserProject',TimesheetControllers.RetreiveUserProject)
router.post('/CreateUpdateTimesheets',TimesheetControllers.CreateUpdateTimesheets)
module.exports=router 