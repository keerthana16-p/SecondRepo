const Timesheet = require('../models/timesheetModel'); // Import the Timesheet model

// Controller function to store timesheet data
const storedata = async (req, res) => {
    try {
        // Generate UUID
        const uuid = generateUUID();

        // Extract data from request body
        const { email, rows } = req.body;

        // Extract dates from rows
        const { start_period, end_period } = rows[0]; // Assuming dates are the same for all rows

        // Create new Timesheet instance
        const timesheet = new Timesheet({
            UID: uuid,
            email,
            start_period,
            end_period,
            activities: rows.map(row => ({
                id: row.id,
                activity: row.activity,
                comments: row.comments,
                mon: row.mon,
                tue: row.tue,
                wed: row.wed,
                thur: row.thur,
                fri: row.fri,
                sat: row.sat,
                sun: row.sun
            }))
        });

        // Save timesheet to database
        await timesheet.save();

        res.status(201).json({ success: true, message: 'Timesheet data saved successfully.' });
    } catch (error) {
        console.error('Error storing timesheet data:', error);
        res.status(500).json({ success: false, message: 'Error storing timesheet data.' });
    }
};

// Function to generate UUID
const generateUUID = () => {
    // Implementation of UUID generation (you can use any UUID generation library)
    // Here's a simple implementation using Math.random():
    const S4 = () => (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
    return `${S4()}${S4()}-${S4()}-${S4()}-${S4()}-${S4()}${S4()}${S4()}`;
};

module.exports = { storedata };
