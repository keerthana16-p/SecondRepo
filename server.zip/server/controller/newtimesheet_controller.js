const Timesheet = require('../models/timesheetModel'); // Import the Timesheet model

const storedata = async (req, res) => {
  try {
      // Generate UUID
      const uuid = generateUUID();
      console.log(req.body.data)

      const { responseEmail } = req.params; // Assuming you're passing responseEmail as a parameter

      // Iterate over each object in req.body.data
      for (const dataObj of req.body.data) {
          const { rowId,projectType, projectName, task, comment, days,startDate,endDate } = dataObj; // Destructure each object

          
          // Calculate hours for each day based on the days array in the request
          const { mon, tue, wed, thur, fri, sat, sun } = calculateHours(days);
          const timesheet = new Timesheet({
              UID:  generateUUID(),  // Assuming responseEmail is used as UID
              email: responseEmail,
              rowid:rowId,
              projectName: projectName,
              task: task,
              mon,
              tue,
              wed,
              thur,
              fri,
              sat,
              sun,
              total: calculateTotalHours(days),
              startDate,
              endDate
          });

          // Save the timesheet to the database
          await timesheet.save();
      }
      
      // Respond with success message
      res.status(201).json({ success: true, message: 'Timesheets created successfully' });
  } catch (error) {
      // Handle errors
      console.error('Error creating timesheets:', error);
      res.status(500).json({ success: false, message: 'Internal server error' });
  }
};

// Helper function to calculate hours for each day
const calculateHours = (days) => {
    // Assuming days is an array containing hours for each day
    const [mon = 0, tue = 0, wed = 0, thur = 0, fri = 0, sat = 0, sun = 0] = days;
    return { mon, tue, wed, thur, fri, sat, sun };
  };
 
  const calculateTotalHours = (days) => {
    // Sum up the values in the days array to calculate the total hours
    const total = days.reduce((acc, day) => acc + day, 0);
    return total;
};

// Function to generate UUID
const generateUUID = () => {
    // Implementation of UUID generation (you can use any UUID generation library)
    // Here's a simple implementation using Math.random():
    const S4 = () => (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
    return `${S4()}${S4()}-${S4()}-${S4()}-${S4()}-${S4()}${S4()}${S4()}`;
};


//to retrive the timesheet details
// Controller function to fetch timesheet data
const getTimesheetDetails = async (req, res) => {
    try {
        const { email, startDate, endDate } = req.params;
        // Fetch timesheet data from the database based on email and date range
        const timesheetData = await Timesheet.find({
            email,
            startDate: { $gte: new Date(startDate) },
            endDate: { $lte: new Date(endDate) }
        });
        console.log("received data",email, startDate, endDate)
        console.log(timesheetData)
        res.json({ rows: timesheetData });
    } catch (error) {
        console.error('Error fetching timesheet data:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
};

module.exports = { storedata ,getTimesheetDetails};
