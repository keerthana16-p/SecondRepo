const Timesheet = require('../models/timesheetModel'); // Import the Timesheet model

// Controller function to store timesheet data
const storedata = async (req, res) => {
    try {
        // Generate UUID
        const uuid = generateUUID();

        const { projectType, projectName, task, comment, days } = req.body.data; // Extracting data from the nested structure

        const { responseEmail } = req.params; // Assuming you're passing responseEmail as a parameter

        // Calculate hours for each day based on the days array in the request
        const { mon, tue, wed, thur, fri, sat, sun } = calculateHours(days);
        const timesheet = new Timesheet({
            UID: responseEmail, // Assuming responseEmail is used as UID
            email: responseEmail,
            projectName: projectName,
            task: task,
            mon,
            tue,
            wed,
            thur,
            fri,
            sat,
            sun
          });
      
          // Save the timesheet to the database
          await timesheet.save();
      
          // Respond with success message
          res.status(201).json({ success: true, message: 'Timesheet created successfully' });
        } catch (error) {
          // Handle errors
          console.error('Error creating timesheet:', error);
          res.status(500).json({ success: false, message: 'Internal server error' });
        }
      };
      
      // Helper function to calculate hours for each day
      const calculateHours = (days) => {
        // Assuming days is an array containing hours for each day
        const [mon, tue, wed, thur, fri, sat, sun] = days;
        return { mon, tue, wed, thur, fri, sat, sun };
      };
       

       

// Function to generate UUID
const generateUUID = () => {
    // Implementation of UUID generation (you can use any UUID generation library)
    // Here's a simple implementation using Math.random():
    const S4 = () => (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
    return `${S4()}${S4()}-${S4()}-${S4()}-${S4()}-${S4()}${S4()}${S4()}`;
};

module.exports = { storedata };
