import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './ResourceAllocation.css';

function ResourceAllocation() {
  const [projects, setProjects] = useState([]); // State to store projects data
  const [users, setUsers] = useState([]); // State to store users data
  const [formData, setFormData] = useState({ // State to manage form data
    projectId: '',
    userIds: [],
    startDate: '',
    endDate: ''
  });
  const [loading, setLoading] = useState(true); // State to manage loading status
  const [error, setError] = useState(''); // State to manage error messages

  // Fetch projects and users data on component mount
  useEffect(() => {
    fetchProjects();
    fetchUsers();
  }, []);

  // Fetch projects data from the backend
  const fetchProjects = () => {
    axios.get('http://localhost:5000/api/projects/projectdetails')
      .then(response => {
        setProjects(response.data.projects);
      })
      .catch(error => {
        setError('Error fetching projects. Please try again later.');
      })
      .finally(() => setLoading(false));
  };

  // Fetch users data from the backend
  const fetchUsers = () => {
    axios.get('http://localhost:5000/api/users/userdetails')
      .then(response => {
        setUsers(response.data.users);
      })
      .catch(error => {
        setError('Error fetching users. Please try again later.');
      })
      .finally(() => setLoading(false));
  };

  // Handle form input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  // Handle user selection from multiselect dropdown
  const handleUserSelection = (e) => {
    const selectedUserIds = Array.from(e.target.selectedOptions, option => option.value);
    setFormData({
      ...formData,
      userIds: selectedUserIds
    });
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('http://localhost:5000/api/resources/allocate-resources', formData)
      .then(response => {
        setFormData({
          projectId: '',
          userIds: [],
          startDate: '',
          endDate: ''
        });
      })
      .catch(error => {
        setError('Error allocating resources. Please try again later.');
      });
  };

  // Render loading message while data is being fetched
  if (loading) {
    return <div>Loading...</div>;
  }

  // Render error message if there is an error fetching data
  if (error) {
    return <div>Error: {error}</div>;
  }

  // Render the resource allocation form
  return (
    <div className="resource-allocation-container">
      <h2>Resource Allocation</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="projectId">Select Projects:</label>
          <select id="projectId" name="projectId" value={formData.projectId} onChange={handleInputChange} required>
            <option value="">Select Projects</option>
            {projects.map(project => (
              <option key={project.id} value={project.id}>{project.name}</option>
            ))}
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="userIds">Select Users:</label>
          <select id="userIds" name="userIds" multiple value={formData.userIds} onChange={handleUserSelection} required>
            {users.map(user => (
              <option key={user.id} value={user.id}>{user.firstName}</option>
            ))}
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="startDate">Start Date:</label>
          <input type="date" id="startDate" name="startDate" value={formData.startDate} onChange={handleInputChange} required />
        </div>
        <div className="form-group">
          <label htmlFor="endDate">End Date:</label>
          <input type="date" id="endDate" name="endDate" value={formData.endDate} onChange={handleInputChange} required />
        </div>
        <button type="submit">Allocate Resources</button>
      </form>
    </div>
  );
}

export default ResourceAllocation;
