import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './UserPage.css';

function UserDashboard() {
  const navigate = useNavigate();
  const [userRole, setUserRole] = useState('');

  useEffect(() => {
    // Fetch user data including role when component mounts
    fetchUserRole();
  }, []);

  const fetchUserRole = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/users/userdetails');
      const role = response.data.role; // Assuming role is returned in the data
      console.log(role)
      setUserRole(role);
    } catch (error) {
      console.error('Error fetching user role:', error);
    }
  };

  const handleTimeSheet = () => {
    // navigate('/create');
  };

  const handleFeedback = () => {
    if (userRole === 'intern') {
      navigate('/internfeedbackform');
    } else if (userRole === 'senior-developer') {
      navigate('/generalfeedbackform');
    }
  };

  const handleTimeSheetStatus = () => {
    // navigate('/resourceAllocation');
  };

  return (
    <div className="user-box">
      <div className="user-dashboard-container">
        <h2 className="user-heading">User Dashboard</h2>
        <div className="user-buttons">
          <button className="user-button" onClick={handleTimeSheet}>TimeSheet</button>
          <button className="user-button" onClick={handleFeedback}>Feedback</button>
          <button className="user-button" onClick={handleTimeSheetStatus}>TimeSheet Status</button>
        </div>
      </div>
    </div>
  );
}

export default UserDashboard;
