import React from 'react';
import { useNavigate } from 'react-router-dom';
import './AdminPage.css';

function AdminDashboard() {
  const navigate = useNavigate();

  const handleAddUser = () => {
    navigate('/create');
  };

  const handleAddProject = () => {
    navigate('/addProject');
  };

  const handleResourceAllocation = () => {
    navigate('/resourceAllocation');
  };

  return (
    <div className="admin-box">
      <div className="admin-dashboard-container">
        <h2 className="admin-heading">Admin Dashboard</h2>
        <div className="admin-buttons">
          <button className="admin-button" onClick={handleAddUser}>Add User</button>
          <button className="admin-button" onClick={handleAddProject}>Add Project</button>
          <button className="admin-button" onClick={handleResourceAllocation}>Allocate Resources</button>
        </div>
      </div>
    </div>
  );
}

export default AdminDashboard;
