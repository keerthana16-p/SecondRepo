// AddProject.js
import React, { useState } from 'react';
import axios from 'axios';
import './AddProject.css';

const AddProject = () => {
  const [id, setProjectId] = useState('');
  const [name, setProjectName] = useState('');
  const [domain, setProjectDomain] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [priority, setPriority] = useState('');

  const handleAddProject = async () => {
    try {
      if (!id || !name || !domain) {
        alert('Please fill out all required fields.');
        return;
      }
      const newProject = {
        id,
        name,
        domain,
        startDate,
        endDate,
        priority
      };

      // Make POST request to backend API
      await axios.post('http://localhost:5000/api/projects/add', newProject);
      
      // Notify user that project has been added
      alert('Project added successfully!');
      
      // Reset form fields after adding project
      setProjectId('');
      setProjectName('');
      setProjectDomain('');
      setStartDate('');
      setEndDate('');
      setPriority('');
    } catch (error) {
      // Handle error
      console.error('Error adding project:', error);
      // Notify user about the error
      alert('Error adding project. Please try again later.');
    }
  };

  return (
    <div className="add-project-container"> 
      <h2>Add Project</h2>
      <label>Project ID:</label>
      <input type="text" value={id} onChange={(e) => setProjectId(e.target.value)} />
      <label>Project Name:</label>
      <input type="text" value={name} onChange={(e) => setProjectName(e.target.value)} />
      <label>Project Domain:</label>
      <input type="text" value={domain} onChange={(e) => setProjectDomain(e.target.value)} />
      <label>Start Date:</label>
      <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
      <label>End Date:</label>
      <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
      <label>Priority:</label>
      <select value={priority} onChange={(e) => setPriority(e.target.value)}>
        <option value="">Select Priority</option>
        <option value="High">High</option>
        <option value="Medium">Medium</option>
        <option value="Low">Low</option>
      </select>
      <button onClick={handleAddProject}>Add Project</button>
    </div>
  );
};

export default AddProject;
