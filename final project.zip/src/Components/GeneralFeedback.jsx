import React, { useState } from 'react';
import Axios from 'axios';
import './GeneralFeedback.css';

function GeneralFeedbackForm() {
  const [feedback, setFeedback] = useState({
    satisfaction: '',
    communication: '',
    goals: '',
    deliverables: '',
    timeliness: '',
    challenges: '',
    projectManagement: '',
    support: '',
    improvements: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFeedback({
      ...feedback,
      [name]: value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await Axios.post('http://localhost:5000/api/feedback/general', feedback);
      console.log(response.data);
      // Handle success if needed
      alert('Feedback submitted successfully!');
    } catch (error) {
      console.error('Error submitting feedback:', error);
      // Handle error if needed
      alert('Failed to submit feedback. Please try again later.');
    }
  };

  return (
    <div className="feedback-form-container">
      <h2>Feedback Form</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="satisfaction">How satisfied are you with the overall outcome of the project?</label>
          <select id="satisfaction" name="satisfaction" value={feedback.satisfaction} onChange={handleChange}>
            <option value="">Select Rating</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="communication">How would you rate the communication and collaboration within the project team?</label>
          <select id="communication" name="communication" value={feedback.communication} onChange={handleChange}>
            <option value="">Select Rating</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="goals">Were the project goals and objectives clearly defined and communicated?</label>
          <select id="goals" name="goals" value={feedback.goals} onChange={handleChange}>
            <option value="">Select Rating</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="deliverables">Did the project deliverables meet the agreed-upon requirements?</label>
          <select id="deliverables" name="deliverables" value={feedback.deliverables} onChange={handleChange}>
            <option value="">Select Rating</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="timeliness">How satisfied are you with the timeliness of project delivery?</label>
          <select id="timeliness" name="timeliness" value={feedback.timeliness} onChange={handleChange}>
            <option value="">Select Rating</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="challenges">Were there any specific challenges or obstacles encountered during the project? If so, please describe.</label>
          <textarea id="challenges" name="challenges" value={feedback.challenges} onChange={handleChange}></textarea>
        </div>
        <div className="form-group">
          <label htmlFor="projectManagement">How would you rate the effectiveness of project management and coordination?</label>
          <select id="projectManagement" name="projectManagement" value={feedback.projectManagement} onChange={handleChange}>
            <option value="">Select Rating</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="support">Did you receive adequate support and assistance from the project team throughout the project lifecycle?</label>
          <select id="support" name="support" value={feedback.support} onChange={handleChange}>
            <option value="">Select Rating</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="improvements">What aspects of the project do you think could be improved in the future?</label>
          <textarea id="improvements" name="improvements" value={feedback.improvements} onChange={handleChange}></textarea>
        </div>
        <button type="submit">Submit Feedback</button>
      </form>
    </div>
  );
}

export default GeneralFeedbackForm;
