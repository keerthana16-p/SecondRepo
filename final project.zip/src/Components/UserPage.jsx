import { useNavigate } from 'react-router-dom';
import './UserPage.css';

function UserDashboard() {
  const navigate = useNavigate();
  const handleTimeSheet = () => {
    // navigate('/create');
  };

  const handleFeedback = () => {
    navigate('/feedbackform')
  };

  const handleTimeSheetStatus = () => {
    // navigate('/resourceAllocation');
  };

  return (
    <div className="user-box">
      <div className="user-dashboard-container">
        <h2 className="user-heading">User Dashboard</h2>
        <div className="user-buttons">
          <button className="user-button" onClick={handleTimeSheet}>TimeSheet</button>
          <button className="user-button" onClick={handleFeedback}>Feedback</button>
          <button className="user-button" onClick={handleTimeSheetStatus}>TimeSheet Status</button>
        </div>
      </div>
    </div>
  );
}

export default UserDashboard;
