import React from 'react';
import { useNavigate } from 'react-router-dom';
import './Feedback.css';

function Feedback() {
  const navigate = useNavigate();

  const handleIntern = () => {
    navigate('/internfeedbackform');
  };

  const handleSeniorDeveloper = () => {
    navigate('/generalfeedbackform');
  };

  const handleConsultant = () => {
    navigate('/consultantfeedbackform');
  };

  const handleTribeMaster = () => {
    navigate('/tribemasterfeedbackform');
  };

  return (
    <div className="feedback-box">
      <div className="feedback-dashboard-container">
        <h2 className="feedback-heading">Role of the User</h2>
        <div className="feedback-buttons">
          <button className="feedback-button" onClick={handleIntern}>Intern</button>
          <button className="feedback-button" onClick={handleSeniorDeveloper}>Senior Developer</button>
          <button className="feedback-button" onClick={handleConsultant}>Consultant</button>
          <button className="feedback-button" onClick={handleTribeMaster}>Tribe Master</button>
        </div>
      </div>
    </div>
  );
}

export default Feedback;
