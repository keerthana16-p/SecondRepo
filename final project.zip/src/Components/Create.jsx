import { useState } from 'react';
import Axios from 'axios';
import './Create.css';

const Create = () => {
    const [firstName, setFirstName] = useState(""); 
    const [lastName, setLastName] = useState(""); 
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("user");
    const [role, setRole] = useState("");

    const handleSubmit = (e) => {
        e.preventDefault();
        Axios.post('http://localhost:5000/api/users/create', { firstName, lastName, email, password, role })
            .then(response => { 
                console.log("hi");
                alert('User added successfully!');
            })
            .catch(err => { 
                console.log('error: ', err);
            });
    }

    return (
        <div className='createuser-container'>
            <form className='form-container' onSubmit={handleSubmit}>
                <h2>Create User</h2>
                <label htmlFor='firstName'>First Name:</label>
                <input type='text' placeholder='First Name' onChange={(e) => setFirstName(e.target.value)} />
                <label htmlFor='lastName'>Last Name:</label>
                <input type='text' placeholder='Last Name' onChange={(e) => setLastName(e.target.value)} />
                <label htmlFor='email'>Email:</label>
                <input type='text' placeholder='Email' onChange={(e) => setEmail(e.target.value)} />
                <label htmlFor='password'>Password:</label>
                <input type='password' placeholder='Password' value={password} onChange={(e) => setPassword(e.target.value)} />
                <label htmlFor='role'>Role:</label>
                <select value={role} onChange={(e) => setRole(e.target.value)}>
                    <option value="">Select Role</option>
                    <option value="Intern">Intern</option>
                    <option value="Senior Developer">Senior Developer</option>
                    <option value="Consultant">Consultant</option>
                    <option value="Tribe Master">Tribe Master</option>
                </select>
                <button type='submit'>Create User</button>
            </form>
        </div>
    );
};

export default Create;
